/*!
 * SAP UI development toolkit for HTML5 (SAPUI5)
 * (c) Copyright 2009-2013 SAP AG or an SAP affiliate company. 
 * Licensed under the Apache License, Version 2.0 - see LICENSE.txt.
 */
jQuery.sap.declare("sap.ui.commons.layout.VerticalLayout");jQuery.sap.require("sap.ui.commons.library");jQuery.sap.require("sap.ui.layout.VerticalLayout");sap.ui.layout.VerticalLayout.extend("sap.ui.commons.layout.VerticalLayout",{metadata:{deprecated:true,library:"sap.ui.commons"}});
