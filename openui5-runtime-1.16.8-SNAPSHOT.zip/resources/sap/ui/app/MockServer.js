/*
 * SAP UI development toolkit for HTML5 (SAPUI5)
 * (c) Copyright 2009-2013 SAP AG or an SAP affiliate company. 
 * Licensed under the Apache License, Version 2.0 - see LICENSE.txt.
 */
jQuery.sap.declare("sap.ui.app.MockServer");jQuery.sap.require("sap.ui.core.util.MockServer");(function(){sap.ui.app.MockServer=sap.ui.core.util.MockServer})();
